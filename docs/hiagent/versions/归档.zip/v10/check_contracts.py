#!/usr/bin/env python3
"""检查完整技能包的引用、单入口、模式一致性及实际 SQL；不模拟 HiAgent。"""
from pathlib import Path
import re
import runpy


# 校验脚本属于仓库维护材料，不放入上传给 HiAgent 的技能包。
ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / "skills/data-asset-query"
REFERENCE_NAMES = {
    "table-schema-kb.md", "table-schema-db.md",
    "dictionary-kb.md", "dictionary-db.md",
}
MODE_NAMES = {"function_call", "plan_and_execute", "react"}
QUERY_PATTERN = r"<!-- query: (\w+) -->\n```sql\n(.*?)\n```"


def check_package():
    """确保每个参考真实可达、只注册一个技能，且 SQL 没有因迁移丢失。"""
    entry = PACKAGE / "SKILL.md"
    assert list(PACKAGE.rglob("SKILL.md")) == [entry], "包内只能有一个注册入口"
    content = entry.read_text()
    assert content.startswith("---\nname: data-asset-query\n")
    # 本包仅使用两个单行纯字符串字段；检查这一有限 YAML 形状，无需新依赖。
    fields = dict(line.split(": ", 1) for line in content.split("---", 2)[1].strip().splitlines())
    assert set(fields) == {"name", "description"}
    assert fields["name"] == PACKAGE.name and fields["description"].strip()
    assert ": " not in fields["description"], "复杂 YAML 值需使用真正的 YAML 验证器"
    targets = re.findall(r"\]\((references/[^)]+)\)", entry.read_text())
    assert len(targets) == len(set(targets)) == len(REFERENCE_NAMES)
    assert {Path(target).name for target in targets} == REFERENCE_NAMES
    queries = {}
    for target in targets:
        path = (PACKAGE / target).resolve()
        assert PACKAGE.resolve() in path.parents and path.is_file(), target
        body = path.read_text()
        assert not body.startswith("---"), "参考不能继续携带旧技能注册信息"
        for key, sql in re.findall(QUERY_PATTERN, body, re.S):
            assert key not in queries, key
            queries[key] = sql
    return queries


def check_modes():
    """保证三种模式使用同一个包，且模式段外没有分叉的业务合同。"""
    prompts = {p.stem: p.read_text() for p in (ROOT / "agent-prompt").glob("*.st")}
    assert set(prompts) == MODE_NAMES
    common = []
    for text in prompts.values():
        assert "data-asset-query" in text
        prefix, mode_and_suffix = text.split("## 模式执行\n", 1)
        mode, suffix = mode_and_suffix.split("## 输出与边界\n", 1)
        assert mode.strip()
        common.append(prefix + suffix)
    assert len(set(common)) == 1, "模式段外的共同规则不同"


def main():
    """复用 V8 的隔离数据判据，执行新包内 SQL，而非只重跑旧文本。"""
    queries = check_package()
    check_modes()
    previous = runpy.run_path(str(ROOT.parent / "v8/check_contracts.py"))
    assert queries == previous["read_queries"](), "迁移改变了已有 SQL 合同"
    database = previous["sample_database"]()
    try:
        previous["check_queries"](database, queries)
        previous["check_dictionary_statistics"](database, queries)
    finally:
        database.close()
    print("通过：单入口、四参考可达、三模式业务一致、新包九 SQL 与隔离数据合同。")
    print("边界：文件加载、模型决策、真实工具顺序、停止及性能仍需 HiAgent 实测。")


if __name__ == "__main__":
    main()
